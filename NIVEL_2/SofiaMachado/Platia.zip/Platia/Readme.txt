Thanks for downloading this template!

Template Name: Platia
Template URL: https://bootstrapmade.com/platia-bootstrap-restaurant-template/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/
